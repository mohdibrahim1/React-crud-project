module.exports ={
    GAPI :'http://localhost:3004/graphql'
}